# easy-bar
Create bar graphs with ease.
